using StavAnalit.RequestManager;

ApplicationConfiguration.Initialize();
using var db = new Database();
db.Initialize();
using var login = new LoginForm(db);
if (login.ShowDialog() == DialogResult.OK && login.Session is not null)
    Application.Run(new MainForm(db, login.Session));
