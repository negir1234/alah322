namespace StavAnalit.RequestManager;

public sealed class LoginForm : Form
{
    readonly Database db;
    readonly TextBox login = new() { Text = "admin", BorderStyle = BorderStyle.FixedSingle };
    readonly TextBox pass = new() { UseSystemPasswordChar = true, Text = "admin123", BorderStyle = BorderStyle.FixedSingle };
    public UserSession? Session { get; private set; }

    public LoginForm(Database database)
    {
        db = database; Text = "СтавЗаявки — вход"; ClientSize = new Size(940, 580);
        StartPosition = FormStartPosition.CenterScreen; FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false; BackColor = UiTheme.Background; Font = new Font("Segoe UI", 10);

        var brand = new Panel { Dock = DockStyle.Left, Width = 420, BackColor = UiTheme.Navy, Padding = new Padding(52) };
        var logo = new Label { Text = "СЗ", AutoSize = false, Size = new Size(62, 62), BackColor = UiTheme.Primary,
            ForeColor = Color.White, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI Semibold", 18) };
        var title = new Label { Text = "СтавЗаявки", ForeColor = Color.White, AutoSize = true,
            Font = new Font("Segoe UI Semibold", 27), Location = new Point(52, 155) };
        var subtitle = new Label { Text = "Единое пространство для работы\nс обращениями клиентов", ForeColor = Color.FromArgb(181, 191, 211),
            AutoSize = true, Font = new Font("Segoe UI", 13), Location = new Point(54, 210) };
        var feature = new Label { Text = "●  Контроль сроков\n\n●  Быстрый поиск\n\n●  Безопасное хранение", ForeColor = Color.FromArgb(214, 220, 234),
            AutoSize = true, Font = new Font("Segoe UI", 11), Location = new Point(56, 325) };
        brand.Controls.AddRange([logo, title, subtitle, feature]); logo.Location = new Point(52, 52);

        var area = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Background };
        var card = new RoundedPanel { Size = new Size(390, 410), BackColor = Color.White, Radius = 20, Padding = new Padding(38) };
        card.Location = new Point(65, 82);
        var heading = new Label { Text = "Добро пожаловать", AutoSize = true, Font = new Font("Segoe UI Semibold", 21), ForeColor = UiTheme.Text, Location = new Point(38, 35) };
        var hint = new Label { Text = "Войдите в свою учётную запись", AutoSize = true, Font = new Font("Segoe UI", 10.5f), ForeColor = UiTheme.Muted, Location = new Point(40, 82) };
        var l1 = Caption("Логин", 130); var l2 = Caption("Пароль", 220);
        login.SetBounds(40, 157, 310, 34); pass.SetBounds(40, 247, 310, 34); UiTheme.StyleInput(login); UiTheme.StyleInput(pass);
        var enter = UiTheme.Button("Войти в систему", UiTheme.Primary, 310); enter.SetBounds(40, 310, 310, 46);
        enter.Click += (_, _) => SignIn();
        var demo = new Label { Text = "Демо: admin / admin123", AutoSize = true, ForeColor = UiTheme.Muted, Font = new Font("Segoe UI", 9), Location = new Point(113, 370) };
        card.Controls.AddRange([heading, hint, l1, login, l2, pass, enter, demo]); area.Controls.Add(card);
        Controls.Add(area); Controls.Add(brand); AcceptButton = enter; UiTheme.Apply(this);
    }
    static Label Caption(string text, int y) => new() { Text = text, AutoSize = true, ForeColor = UiTheme.Text, Font = new Font("Segoe UI Semibold", 10), Location = new Point(40, y) };
    void SignIn() { Session = db.Login(login.Text.Trim(), pass.Text); if (Session is null) MessageBox.Show("Проверьте логин и пароль.", "Не удалось войти", MessageBoxButtons.OK, MessageBoxIcon.Warning); else DialogResult = DialogResult.OK; }
}
