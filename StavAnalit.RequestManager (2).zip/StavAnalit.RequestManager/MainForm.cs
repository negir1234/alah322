using System.Data;
using System.Text;

namespace StavAnalit.RequestManager;

public sealed class MainForm : Form
{
    readonly Database db;
    readonly UserSession user;
    readonly DataGridView grid = new();
    readonly TextBox search = new();
    readonly Label totalValue = MetricValue();
    readonly Label workValue = MetricValue();
    readonly Label doneValue = MetricValue();
    readonly Label clock = new();

    public MainForm(Database database, UserSession session)
    {
        db = database; user = session;
        Text = "СтавЗаявки — рабочее пространство";
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(1180, 720);
        BackColor = UiTheme.Background;
        Font = new Font("Segoe UI", 10);

        var sidebar = BuildSidebar();
        var workspace = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Background };
        var top = BuildTopBar();
        var page = BuildPage();
        workspace.Controls.Add(page);
        workspace.Controls.Add(top);
        Controls.Add(workspace);
        Controls.Add(sidebar);

        ConfigureGrid();
        LoadData();
        db.Audit(user, "Вход в систему", "Сеанс");
    }

    Panel BuildSidebar()
    {
        var side = new Panel { Dock = DockStyle.Left, Width = 238, BackColor = UiTheme.Navy, Padding = new Padding(18, 24, 18, 20) };
        var logo = new Label { Dock = DockStyle.Top, Height = 72, Text = "  ◈  СтавЗаявки", ForeColor = Color.White, Font = new Font("Segoe UI Semibold", 17), TextAlign = ContentAlignment.MiddleLeft };
        var section = new Label { Dock = DockStyle.Top, Height = 42, Text = "РАБОЧЕЕ МЕСТО", ForeColor = Color.FromArgb(119, 150, 163), Font = new Font("Segoe UI Semibold", 8), TextAlign = ContentAlignment.BottomLeft, Padding = new Padding(12, 0, 0, 8) };
        var nav = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 260, FlowDirection = FlowDirection.TopDown, WrapContents = false, BackColor = UiTheme.Navy };
        var requests = NavButton("▣   Заявки", true); requests.Click += (_, _) => LoadData();
        var clients = NavButton("♙   Клиенты"); clients.Click += (_, _) => Clients();
        nav.Controls.Add(requests); nav.Controls.Add(clients);
        if (user.Role == "Администратор") { var users = NavButton("♟   Пользователи"); users.Click += (_, _) => Users(); nav.Controls.Add(users); }
        var toolsTitle = new Label { Dock = DockStyle.Top, Height = 38, Text = "ДАННЫЕ", ForeColor = Color.FromArgb(119, 150, 163), Font = new Font("Segoe UI Semibold", 8), TextAlign = ContentAlignment.BottomLeft, Padding = new Padding(12, 0, 0, 8) };
        var tools = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 130, FlowDirection = FlowDirection.TopDown, WrapContents = false, BackColor = UiTheme.Navy };
        var export = NavButton("⇩   Экспорт в CSV"); export.Click += (_, _) => Export();
        var backup = NavButton("◫   Резервная копия"); backup.Click += (_, _) => Backup();
        tools.Controls.Add(export); tools.Controls.Add(backup);
        var exit = NavButton("↪   Выйти"); exit.Dock = DockStyle.Bottom; exit.ForeColor = Color.FromArgb(255, 177, 185); exit.Click += (_, _) => Close();
        side.Controls.Add(exit); side.Controls.Add(tools); side.Controls.Add(toolsTitle); side.Controls.Add(nav); side.Controls.Add(section); side.Controls.Add(logo);
        return side;
    }

    Panel BuildTopBar()
    {
        var top = new Panel { Dock = DockStyle.Top, Height = 76, BackColor = Color.White, Padding = new Padding(30, 0, 30, 0) };
        var location = new Label { Dock = DockStyle.Left, Width = 360, Text = "ООО «СтавАналит»  /  Отдел поддержки", ForeColor = UiTheme.Muted, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9.5f) };
        clock.Dock = DockStyle.Right; clock.Width = 200; clock.ForeColor = UiTheme.Text; clock.TextAlign = ContentAlignment.MiddleRight; clock.Font = new Font("Segoe UI Semibold", 10);
        var profile = new Label { Dock = DockStyle.Right, Width = 280, Text = $"{user.FullName}\n{user.Role}", ForeColor = UiTheme.Text, TextAlign = ContentAlignment.MiddleRight, Font = new Font("Segoe UI", 9.5f), Padding = new Padding(0, 0, 18, 0) };
        var timer = new System.Windows.Forms.Timer { Interval = 1000 }; timer.Tick += (_, _) => clock.Text = DateTime.Now.ToString("dd MMMM  •  HH:mm"); timer.Start(); clock.Text = DateTime.Now.ToString("dd MMMM  •  HH:mm");
        top.Controls.Add(location); top.Controls.Add(clock); top.Controls.Add(profile);
        return top;
    }

    Panel BuildPage()
    {
        var page = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Background, Padding = new Padding(30, 26, 30, 26) };
        var heading = new Panel { Dock = DockStyle.Top, Height = 74, BackColor = UiTheme.Background };
        heading.Controls.Add(new Label { Text = "Заявки клиентов", AutoSize = true, Location = new Point(0, 0), ForeColor = UiTheme.Text, Font = new Font("Segoe UI Semibold", 24) });
        heading.Controls.Add(new Label { Text = "Приём, распределение и контроль выполнения", AutoSize = true, Location = new Point(2, 42), ForeColor = UiTheme.Muted, Font = new Font("Segoe UI", 10.5f) });
        var create = UiTheme.Button("＋  Создать заявку", UiTheme.Primary, 178); create.Anchor = AnchorStyles.Top | AnchorStyles.Right; create.Location = new Point(heading.Width - 178, 8); heading.Resize += (_, _) => create.Left = heading.Width - create.Width; create.Click += (_, _) => Edit(); heading.Controls.Add(create);

        var metrics = new TableLayoutPanel { Dock = DockStyle.Top, Height = 92, ColumnCount = 3, BackColor = UiTheme.Background, Padding = new Padding(0, 0, 0, 14) };
        metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f)); metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f)); metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.334f));
        metrics.Controls.Add(Metric("Все обращения", "Полный журнал", totalValue, UiTheme.Primary), 0, 0);
        metrics.Controls.Add(Metric("Требуют внимания", "Новые и в работе", workValue, Color.FromArgb(239, 147, 45)), 1, 0);
        metrics.Controls.Add(Metric("Завершены", "Успешно закрыты", doneValue, Color.FromArgb(64, 174, 120)), 2, 0);

        var command = new Panel { Dock = DockStyle.Top, Height = 66, BackColor = Color.White, Padding = new Padding(18, 14, 18, 10) };
        search.PlaceholderText = "Номер, клиент или тема"; search.SetBounds(18, 15, 330, 36); search.BorderStyle = BorderStyle.FixedSingle; search.Font = new Font("Segoe UI", 10.5f); search.ForeColor = UiTheme.Text; search.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) LoadData(); };
        var find = UiTheme.Button("Найти", UiTheme.Primary, 92); find.SetBounds(360, 14, 92, 38); find.Click += (_, _) => LoadData();
        var clear = GhostButton("Сбросить", 92); clear.SetBounds(460, 14, 92, 38); clear.Click += (_, _) => { search.Clear(); LoadData(); };
        var edit = GhostButton("Изменить", 108); edit.Anchor = AnchorStyles.Top | AnchorStyles.Right; edit.Click += (_, _) => Edit(SelectedId());
        var delete = UiTheme.Button("Удалить", UiTheme.Danger, 100); delete.Anchor = AnchorStyles.Top | AnchorStyles.Right; delete.Click += (_, _) => Delete();
        command.Resize += (_, _) => { delete.SetBounds(command.Width - 118, 14, 100, 38); edit.SetBounds(command.Width - 236, 14, 108, 38); };
        command.Controls.AddRange([search, find, clear, edit, delete]);

        var listHeader = new Panel { Dock = DockStyle.Top, Height = 48, BackColor = Color.White, Padding = new Padding(18, 0, 18, 0) };
        listHeader.Controls.Add(new Label { Dock = DockStyle.Left, Width = 300, Text = "Последние обращения", ForeColor = UiTheme.Text, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI Semibold", 12) });
        var list = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(18, 0, 18, 16) }; list.Controls.Add(grid);
        page.Controls.Add(list); page.Controls.Add(listHeader); page.Controls.Add(command); page.Controls.Add(metrics); page.Controls.Add(heading);
        return page;
    }

    void ConfigureGrid()
    {
        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.MultiSelect = false; grid.AllowUserToAddRows = false; grid.AllowUserToResizeRows = false; grid.RowHeadersVisible = false; grid.BorderStyle = BorderStyle.None; grid.BackgroundColor = Color.White; grid.GridColor = Color.FromArgb(230, 236, 239); grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersHeight = 44; grid.RowTemplate.Height = 46;
        grid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(235, 241, 243), ForeColor = UiTheme.Text, Font = new Font("Segoe UI Semibold", 9.5f), Alignment = DataGridViewContentAlignment.MiddleLeft, Padding = new Padding(6, 0, 0, 0), SelectionBackColor = Color.FromArgb(235, 241, 243), SelectionForeColor = UiTheme.Text };
        grid.DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.White, ForeColor = UiTheme.Text, SelectionBackColor = Color.FromArgb(218, 243, 241), SelectionForeColor = UiTheme.Text, Font = new Font("Segoe UI", 9.5f), Padding = new Padding(6, 0, 0, 0) };
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(249, 251, 252);
        grid.CellDoubleClick += (_, _) => Edit(SelectedId()); grid.CellFormatting += FormatCell;
    }

    static Button NavButton(string text, bool active = false) { var b = new Button { Text = text, Width = 202, Height = 46, FlatStyle = FlatStyle.Flat, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(12, 0, 0, 0), Font = new Font("Segoe UI Semibold", 10), ForeColor = active ? Color.White : Color.FromArgb(190, 207, 215), BackColor = active ? UiTheme.PrimaryDark : UiTheme.Navy, Cursor = Cursors.Hand, Margin = new Padding(0, 0, 0, 5) }; b.FlatAppearance.BorderSize = 0; b.FlatAppearance.MouseOverBackColor = Color.FromArgb(24, 59, 74); return b; }
    static Button GhostButton(string text, int width) { var b = new Button { Text = text, Width = width, Height = 38, FlatStyle = FlatStyle.Flat, BackColor = Color.White, ForeColor = UiTheme.Text, Font = new Font("Segoe UI Semibold", 9.5f), Cursor = Cursors.Hand }; b.FlatAppearance.BorderColor = UiTheme.Border; return b; }
    static Label MetricValue() => new() { Dock = DockStyle.Right, Width = 75, Text = "0", ForeColor = UiTheme.Text, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Segoe UI Semibold", 23) };
    static Panel Metric(string title, string subtitle, Label value, Color accent) { var outer = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Background, Padding = new Padding(0, 0, 12, 0) }; var card = new Panel { Dock = DockStyle.Fill, BackColor = Color.White }; var bar = new Panel { Dock = DockStyle.Left, Width = 5, BackColor = accent }; var text = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18, 12, 0, 8) }; text.Controls.Add(new Label { Dock = DockStyle.Top, Height = 24, Text = title, ForeColor = UiTheme.Text, Font = new Font("Segoe UI Semibold", 11) }); text.Controls.Add(new Label { Dock = DockStyle.Bottom, Height = 22, Text = subtitle, ForeColor = UiTheme.Muted, Font = new Font("Segoe UI", 9) }); card.Controls.Add(text); card.Controls.Add(value); card.Controls.Add(bar); outer.Controls.Add(card); return outer; }

    void LoadData()
    {
        const string sql = "SELECT r.Id,r.Number AS 'Номер',c.Name AS 'Клиент',r.Subject AS 'Тема',r.Status AS 'Статус',r.Priority AS 'Приоритет',r.Assignee AS 'Исполнитель',r.CreatedAt AS 'Создана',r.DueAt AS 'Срок' FROM Requests r JOIN Clients c ON c.Id=r.ClientId WHERE r.Number LIKE $q OR c.Name LIKE $q OR r.Subject LIKE $q ORDER BY r.Id DESC";
        grid.DataSource = db.Query(sql, ("$q", "%" + search.Text.Trim() + "%"));
        var idColumn = grid.Columns["Id"]; if (idColumn is not null) idColumn.Visible = false;
        totalValue.Text = Convert.ToString(db.Scalar("SELECT COUNT(*) FROM Requests")); workValue.Text = Convert.ToString(db.Scalar("SELECT COUNT(*) FROM Requests WHERE Status IN ('Новая','В работе','Ожидает')")); doneValue.Text = Convert.ToString(db.Scalar("SELECT COUNT(*) FROM Requests WHERE Status='Выполнена'"));
    }
    void FormatCell(object? sender, DataGridViewCellFormattingEventArgs e) { if (e.RowIndex < 0 || grid.Columns[e.ColumnIndex].Name != "Статус" || e.Value is not string value) return; e.CellStyle.ForeColor = value switch { "Выполнена" => Color.FromArgb(31, 137, 87), "Отменена" => UiTheme.Danger, "В работе" => Color.FromArgb(0, 126, 124), _ => Color.FromArgb(191, 111, 12) }; e.CellStyle.Font = new Font("Segoe UI Semibold", 9.5f); }
    long? SelectedId() => grid.CurrentRow?.Cells["Id"].Value is object value ? Convert.ToInt64(value) : null;
    void Edit(long? id = null) { using var form = new RequestForm(db, id); if (form.ShowDialog() == DialogResult.OK) { db.Audit(user, id is null ? "Создание" : "Изменение", "Заявка"); LoadData(); } }
    void Delete() { var id = SelectedId(); if (id is null || MessageBox.Show("Удалить выбранную заявку?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return; using var command = db.Connection.CreateCommand(); command.CommandText = "DELETE FROM Requests WHERE Id=$id"; command.Parameters.AddWithValue("$id", id); command.ExecuteNonQuery(); db.Audit(user, "Удаление", "Заявка " + id); LoadData(); }
    void Clients() { using var form = new DirectoryForm(db, "Клиенты"); form.ShowDialog(); LoadData(); }
    void Users() { using var form = new DirectoryForm(db, "Пользователи"); form.ShowDialog(); }
    void Backup() { using var dialog = new SaveFileDialog { Filter = "База SQLite|*.db", FileName = $"stavanalit_backup_{DateTime.Now:yyyyMMdd}.db" }; if (dialog.ShowDialog() != DialogResult.OK) return; db.Backup(dialog.FileName); db.Audit(user, "Резервное копирование", "База данных"); MessageBox.Show("Резервная копия создана.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information); }
    void Export() { using var dialog = new SaveFileDialog { Filter = "CSV|*.csv", FileName = $"Заявки_{DateTime.Now:yyyyMMdd}.csv" }; if (dialog.ShowDialog() != DialogResult.OK) return; var table = (DataTable)grid.DataSource; var columns = table.Columns.Cast<DataColumn>().Where(x => x.ColumnName != "Id").ToArray(); var csv = new StringBuilder().AppendLine(string.Join(';', columns.Select(x => x.ColumnName))); foreach (DataRow row in table.Rows) csv.AppendLine(string.Join(';', columns.Select(x => '"' + row[x].ToString()!.Replace("\"", "\"\"") + '"'))); File.WriteAllText(dialog.FileName, csv.ToString(), new UTF8Encoding(true)); db.Audit(user, "Экспорт", "Заявки CSV"); }
}
