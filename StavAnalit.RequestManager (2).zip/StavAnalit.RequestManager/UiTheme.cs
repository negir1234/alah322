using System.Drawing.Drawing2D;

namespace StavAnalit.RequestManager;

internal static class UiTheme
{
    public static readonly Color Background = Color.FromArgb(242, 246, 248);
    public static readonly Color Surface = Color.White;
    public static readonly Color Navy = Color.FromArgb(14, 35, 49);
    public static readonly Color Text = Color.FromArgb(24, 45, 58);
    public static readonly Color Muted = Color.FromArgb(100, 119, 130);
    public static readonly Color Primary = Color.FromArgb(0, 157, 154);
    public static readonly Color PrimaryDark = Color.FromArgb(0, 126, 124);
    public static readonly Color Danger = Color.FromArgb(226, 74, 94);
    public static readonly Color Border = Color.FromArgb(226, 231, 240);

    public static Button Button(string text, Color? color = null, int width = 145)
    {
        var button = new Button {
            Text = text, Width = width, Height = 42, FlatStyle = FlatStyle.Flat,
            BackColor = color ?? Primary, ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 10), Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 10, 0), UseVisualStyleBackColor = false
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    public static void StyleInput(Control input)
    {
        input.Font = new Font("Segoe UI", 10.5f);
        input.BackColor = Color.White;
        input.ForeColor = Text;
        input.Margin = new Padding(0, 4, 0, 12);
    }

    public static Panel Card(int padding = 20) => new() {
        BackColor = Surface, Padding = new Padding(padding), Margin = new Padding(8)
    };

    public static void Apply(Control root)
    {
        foreach (Control control in root.Controls)
        {
            if (control is Label && control.ForeColor == SystemColors.ControlText)
                control.ForeColor = Text;
            if (control is TextBox or ComboBox or DateTimePicker)
                StyleInput(control);
            Apply(control);
        }
    }
}

internal sealed class RoundedPanel : Panel
{
    public int Radius { get; set; } = 18;
    public Color BorderColor { get; set; } = UiTheme.Border;
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var path = new GraphicsPath();
        var r = Radius * 2; var box = new Rectangle(0, 0, Width - 1, Height - 1);
        path.AddArc(box.X, box.Y, r, r, 180, 90); path.AddArc(box.Right-r, box.Y, r, r, 270, 90);
        path.AddArc(box.Right-r, box.Bottom-r, r, r, 0, 90); path.AddArc(box.X, box.Bottom-r, r, r, 90, 90); path.CloseFigure();
        Region = new Region(path);
        using var pen = new Pen(BorderColor); e.Graphics.DrawPath(pen, path);
    }
}
