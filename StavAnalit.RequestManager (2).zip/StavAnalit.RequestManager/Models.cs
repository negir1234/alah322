namespace StavAnalit.RequestManager;

public sealed record UserSession(long Id, string Login, string FullName, string Role);
public sealed record RequestRow(long Id, string Number, string Client, string Subject, string Status, string Priority, string Assignee, string CreatedAt, string DueAt);
