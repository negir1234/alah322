using Microsoft.Data.Sqlite;
using System.Security.Cryptography;
using System.Text;

namespace StavAnalit.RequestManager;

public sealed class Database : IDisposable
{
    private readonly string _file = Path.Combine(AppContext.BaseDirectory, "stavanalit.db");
    private SqliteConnection? _connection;
    public SqliteConnection Connection => _connection ??= new SqliteConnection($"Data Source={_file}");
    public void Initialize()
    {
        Connection.Open();
        using var cmd = Connection.CreateCommand();
        cmd.CommandText = @"PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS Users(Id INTEGER PRIMARY KEY, Login TEXT UNIQUE NOT NULL, PasswordHash TEXT NOT NULL, FullName TEXT NOT NULL, Role TEXT NOT NULL, IsActive INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS Clients(Id INTEGER PRIMARY KEY, Name TEXT NOT NULL, Phone TEXT, Email TEXT, Notes TEXT);
CREATE TABLE IF NOT EXISTS Requests(Id INTEGER PRIMARY KEY, Number TEXT UNIQUE NOT NULL, ClientId INTEGER NOT NULL REFERENCES Clients(Id), Subject TEXT NOT NULL, Description TEXT, Status TEXT NOT NULL, Priority TEXT NOT NULL, Assignee TEXT, CreatedAt TEXT NOT NULL, DueAt TEXT, ClosedAt TEXT);
CREATE TABLE IF NOT EXISTS Audit(Id INTEGER PRIMARY KEY, UserId INTEGER, Action TEXT NOT NULL, Entity TEXT NOT NULL, CreatedAt TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS IX_Requests_Status ON Requests(Status);
CREATE INDEX IF NOT EXISTS IX_Requests_CreatedAt ON Requests(CreatedAt);";
        cmd.ExecuteNonQuery();
        if (Convert.ToInt64(Scalar("SELECT COUNT(*) FROM Users")) == 0) AddUser("admin", "admin123", "Администратор системы", "Администратор");
        if (Convert.ToInt64(Scalar("SELECT COUNT(*) FROM Clients")) == 0) { AddClient("ООО «Кавказ-Агро»", "+7 (8652) 21-00-01", "info@kavkaz-agro.ru", "Демонстрационный клиент"); AddClient("ИП Петров", "+7 (8652) 21-00-02", "petrov@example.ru", ""); }
        if (Convert.ToInt64(Scalar("SELECT COUNT(*) FROM Requests")) == 0) AddRequest(1, "Заявка на настройку рабочего места", "Настроить программное обеспечение и подключить принтер.", "Новая", "Высокий", "", DateTime.Now.AddDays(2));
    }
    public object Scalar(string sql, params (string, object)[] p) { using var c=Connection.CreateCommand(); c.CommandText=sql; foreach(var x in p)c.Parameters.AddWithValue(x.Item1,x.Item2); return c.ExecuteScalar() ?? 0; }
    public UserSession? Login(string login,string password) { using var c=Connection.CreateCommand(); c.CommandText="SELECT Id,Login,FullName,Role FROM Users WHERE Login=$l AND PasswordHash=$p AND IsActive=1"; c.Parameters.AddWithValue("$l",login); c.Parameters.AddWithValue("$p",Hash(password)); using var r=c.ExecuteReader(); return r.Read()?new UserSession(r.GetInt64(0),r.GetString(1),r.GetString(2),r.GetString(3)):null; }
    public void AddUser(string login,string password,string name,string role) { using var c=Connection.CreateCommand(); c.CommandText="INSERT INTO Users(Login,PasswordHash,FullName,Role) VALUES($l,$p,$n,$r)"; c.Parameters.AddWithValue("$l",login);c.Parameters.AddWithValue("$p",Hash(password));c.Parameters.AddWithValue("$n",name);c.Parameters.AddWithValue("$r",role);c.ExecuteNonQuery(); }
    public void AddClient(string name,string phone,string email,string notes) { using var c=Connection.CreateCommand(); c.CommandText="INSERT INTO Clients(Name,Phone,Email,Notes) VALUES($n,$p,$e,$o)"; c.Parameters.AddWithValue("$n",name);c.Parameters.AddWithValue("$p",phone);c.Parameters.AddWithValue("$e",email);c.Parameters.AddWithValue("$o",notes);c.ExecuteNonQuery(); }
    public long AddRequest(long client,string subject,string description,string status,string priority,string assignee,DateTime due) { using var c=Connection.CreateCommand(); c.CommandText="INSERT INTO Requests(Number,ClientId,Subject,Description,Status,Priority,Assignee,CreatedAt,DueAt) VALUES($num,$c,$s,$d,$st,$p,$a,$ca,$due); SELECT last_insert_rowid();"; c.Parameters.AddWithValue("$num",$"З-{DateTime.Now:yyyyMMddHHmmss}");c.Parameters.AddWithValue("$c",client);c.Parameters.AddWithValue("$s",subject);c.Parameters.AddWithValue("$d",description);c.Parameters.AddWithValue("$st",status);c.Parameters.AddWithValue("$p",priority);c.Parameters.AddWithValue("$a",assignee);c.Parameters.AddWithValue("$ca",DateTime.Now.ToString("dd.MM.yyyy HH:mm"));c.Parameters.AddWithValue("$due",due.ToString("dd.MM.yyyy")); return (long)c.ExecuteScalar()!; }
    public void Audit(UserSession s,string action,string entity){using var c=Connection.CreateCommand();c.CommandText="INSERT INTO Audit(UserId,Action,Entity,CreatedAt) VALUES($u,$a,$e,$d)";c.Parameters.AddWithValue("$u",s.Id);c.Parameters.AddWithValue("$a",action);c.Parameters.AddWithValue("$e",entity);c.Parameters.AddWithValue("$d",DateTime.Now.ToString("dd.MM.yyyy HH:mm"));c.ExecuteNonQuery();}
    public System.Data.DataTable Query(string sql, params (string,object)[] p){using var c=Connection.CreateCommand();c.CommandText=sql;foreach(var x in p)c.Parameters.AddWithValue(x.Item1,x.Item2);using var reader=c.ExecuteReader();var t=new System.Data.DataTable();t.Load(reader);return t;}
    public void Backup(string target)=>File.Copy(_file,target,true);
    static string Hash(string s)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(s)));
    public void Dispose()=>Connection.Dispose();
}
